# A Simple PyTorch deep learning REST API

## Starting the pytorch server

```bash
python run_pytorch_server.py 
```

You can now access the REST API via `http://127.0.0.1:5000/predict`

## Submitting requests to pytorch server

```bash
python simple_request.py --file='file_path'
```


## Acknowledgement
This repository refers to [L1aoXingyu/deploy-pytorch-model](https://github.com/L1aoXingyu/deploy-pytorch-model).