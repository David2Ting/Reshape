import base64
import io

import cv2
import flask
import numpy as np
import torch
from PIL import Image
from torchvision import transforms as T

from model.unet import UNet

# Initialize our Flask application and the PyTorch model.
app = flask.Flask(__name__)
model = None
input_img_size = 256
use_gpu = True and torch.cuda.is_available()
dev = 'cuda:0' if use_gpu else 'cpu'
device = torch.device(dev)


def load_model():
    global model
    n_channels, n_classes = 1, 1
    model = UNet(n_channels, n_classes)
    model.load_state_dict(torch.load('model/weights.pth', map_location=device))
    model.eval()
    model.to(device)


def prepare_image(image: Image.Image, target_size: int):
    """
    Returns pre-processed image for model.

    :param image: input image.
    :param target_size: dimensions to resize and crop.
    :return: 1xCxHxW tensor.
    """
    transforms = T.Compose([
        T.Resize(target_size),
        T.CenterCrop(target_size),
        T.Grayscale(num_output_channels=1),
        T.ToTensor(),
        # T.Normalize(mean=[0.5], std=[0.5]),
    ])
    image = transforms(image)

    # Add batch_size axis.
    image = image.unsqueeze(1)
    return image.to(device)


@app.route("/predict", methods=["POST"])
def predict():
    # Initialize the data dictionary that will be returned from the view.
    data = {"success": False}

    # Ensure an image was properly uploaded to our endpoint.
    if flask.request.method == 'POST':
        if flask.request.files.get("image"):
            # Read the image in PIL format
            image = flask.request.files["image"].read()
            image = Image.open(io.BytesIO(image))
            temp0 = np.array(image)

            # Preprocess the image and prepare it for classification.
            image = prepare_image(image, target_size=input_img_size)
            # temp1 = unnormalise(image.squeeze(1))

            # cv2.imshow("pre", np.hstack([temp0, temp1]))
            # cv2.waitKey()
            # cv2.destroyAllWindows()

            # Classify the input image and then initialize the list of predictions to return to the client.
            pred = model(image).squeeze(1)

            # Encode image for return
            pred = np.array(T.ToPILImage()(pred.detach().cpu()))
            success, encoded_image = cv2.imencode('.png', pred)
            encoded_image_bytes = encoded_image.tobytes()
            encoded = base64.b64encode(encoded_image_bytes).decode('utf-8')
            data['mask'] = encoded
            data['encoding'] = '.png'

            # Indicate that the request was a success.
            data["success"] = True

    # Return the data dictionary as a JSON response.
    return flask.jsonify(data)


if __name__ == '__main__':
    print("Loading PyTorch model and Flask starting server ...")
    print("Please wait until server has fully started")
    load_model()
    app.run()
