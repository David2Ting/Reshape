import React, { Component } from 'react';
import Note8 from "./Note8"

class HackathonScreen extends Component {
  render() {
    return (

      //Note 
      <div>
        <Note8>
          {this.props.children}
        </Note8>
      </div>
    );
  }
}

export default HackathonScreen;
