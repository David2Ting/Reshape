import React, { Component } from 'react';
import '../css/App.css';
import { PacmanLoader } from "react-spinners";
import Note8 from "../Note8"
import { Button } from 'reactstrap';
import HackathonScreen from '../HackathonScreen';


class NearestGP extends Component {

  state = {
    ready: false // Tells the render whether this page is ready
  }

  //componentDidMount is a method that runs after the Home component is
  //added to the DOM
  componentDidMount() {
    setTimeout(() => this.setState({ ready: true }), 2000);
  }

  renderLoading() {
    return (
        <PacmanLoader color='rgb(255, 91, 91)'/>
    )
  }

  renderBody() {
    return (
      <div>
        <Button color="danger">Mole Checkup</Button>
        <Button color="primary">Mole History</Button>
        <Button color="warning">Self Care</Button>
        <Button color="success">Nearest GP</Button>
      </div>
    )
  }

  render() {
    return (

      //Router enables switching of different pages
      <HackathonScreen>
        {this.state.ready ? this.renderBody() : this.renderLoading()}
      </HackathonScreen>
    );
  }
}

export default NearestGP;
