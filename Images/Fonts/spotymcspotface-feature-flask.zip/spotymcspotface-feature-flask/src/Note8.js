import React, { Component } from 'react';
import './css/devices.min.css';

class Note8 extends Component {
  render() {
    return (
        <div class="marvel-device note8">
          <div class="inner"></div>
            <div class="overflow">
                <div class="shadow"></div>
            </div>
            <div class="speaker"></div>
            <div class="sensors"></div>
            <div class="more-sensors"></div>
            <div class="sleep"></div>
            <div class="volume"></div>
            <div class="camera"></div>

          // SCREEN RENDERS GO BELOW
          <div class="screen" style={{ height: '100%'}}>
            <div className="app-container" style={{ height: '100%', display: 'flex', flexDirection: 'column', position: 'relative' }}>
              {this.props.children}
            </div>
          </div>
        </div>
    )
  }
}

export default Note8
