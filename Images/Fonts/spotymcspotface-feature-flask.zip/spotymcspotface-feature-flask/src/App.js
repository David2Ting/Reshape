import React, { Component } from 'react';
import './css/App.css';
import { BrowserRouter as Router } from 'react-router-dom';
import HackathonScreen from './HackathonScreen';
import Home from "./Pages/Home"

class App extends Component {
  render() {
    return (

      // HackathonScreen is rendered to display what users will see in the hackathon
      // <HackathonScreen>
      //   <p>Some stuff</p>
      // </HackathonScreen>
      <div>
        <Home />
      </div>
    );
  }
}

export default App;
